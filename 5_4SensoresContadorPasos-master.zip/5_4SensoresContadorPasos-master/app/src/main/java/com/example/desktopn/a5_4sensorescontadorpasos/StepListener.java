package com.example.desktopn.a5_4sensorescontadorpasos;

public interface StepListener {
        public void step(long timeNs);
}
