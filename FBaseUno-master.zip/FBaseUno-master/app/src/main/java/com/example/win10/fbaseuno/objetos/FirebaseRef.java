package com.example.win10.fbaseuno.objetos;

public class FirebaseRef {
    final public static String TUTORIAL_REFERENCE = "Tutorial";
    final public static String ALUMNO_REFERENCE = "Alumno";
}
