package com.example.win10.a3_3_1_serviciosweb;

public interface ServerResponse {
    void procesarRespuesta(String r);
}
